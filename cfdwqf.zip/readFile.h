#include "classes.h"


#ifndef __readfile_h__
#define __readfile_h__

node* readFile(char *);

#endif